@echo off
rem Create the ICLS shortcut on the Desktop. (File names inside are ASCII on purpose.)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1"
if errorlevel 1 (
  echo.
  echo Failed. Please create the shortcut by hand. See the README.
)
pause
