@echo off
rem Create the ICLS shortcut on the Desktop using Google Chrome (use this if Edge does not work on the PC).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1" -Browser Chrome
if errorlevel 1 (
  echo.
  echo Failed. Please create the shortcut by hand. See the README.
)
pause
