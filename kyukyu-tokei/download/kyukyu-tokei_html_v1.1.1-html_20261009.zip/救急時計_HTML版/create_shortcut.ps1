﻿# ICLS救急時計: デスクトップにショートカットを作る
# Edge（無ければ Chrome）の「アプリ表示」（アドレスバーのない専用の窓）で 救急時計.html を開くショートカットを作ります。
# 通常の Edge の窓でも開けますが、アプリ表示のほうが誤って別のページへ移動しにくく、画面を広く使えます。
#
# 使い方: 「ショートカットを作る.bat」をダブルクリック（このファイルを直接実行しても同じです）
# 作る場所を変えるとき: powershell -File create_shortcut.ps1 -OutDir "C:\任意のフォルダ"
# 使うブラウザを指定するとき: powershell -File create_shortcut.ps1 -Browser Chrome   （既定は Auto＝Edge を探し、無ければ Chrome）
param([string]$OutDir = [Environment]::GetFolderPath('Desktop'), [ValidateSet('Auto','Edge','Chrome')][string]$Browser = 'Auto')
$ErrorActionPreference = 'Stop'

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$html = Join-Path $here '救急時計.html'
if (-not (Test-Path -LiteralPath $html)) { throw "救急時計.html が見つかりません: $html" }

$edgePaths = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")
$chromePaths = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
$edge = $edgePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$chrome = $chromePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
$exe = switch ($Browser) { 'Edge' { $edge } 'Chrome' { $chrome } default { if ($edge) { $edge } else { $chrome } } }
if (-not $exe) { throw 'Microsoft Edge も Google Chrome も見つかりません。-Browser で指定するか、手でショートカットを作ってください。' }
Write-Host "使うブラウザ: $exe"

# 日本語や空白を含む場所でも開けるよう、file:// のURLに直す（自動でエンコードされる）
$uri = ([System.Uri]$html).AbsoluteUri

$shell = New-Object -ComObject WScript.Shell
$lnkPath = Join-Path $OutDir 'ICLS救急時計.lnk'
$lnk = $shell.CreateShortcut($lnkPath)
$lnk.TargetPath = $exe
$lnk.Arguments = "--app=$uri"
$lnk.WorkingDirectory = $here
$lnk.Description = 'ICLS救急時計'
$ico = Join-Path $here '救急時計.ico'
if (Test-Path -LiteralPath $ico) { $lnk.IconLocation = $ico }
$lnk.Save()

Write-Host "ショートカットを作りました: $lnkPath"
Write-Host '  ※ 救急時計.html（とこのフォルダ）は、置いた場所から動かさないでください。動かした場合は、ショートカットを作り直してください。'
